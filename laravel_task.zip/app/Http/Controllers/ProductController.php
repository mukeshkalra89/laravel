<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Product_category;
use Auth;
use DB;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

   //products listing function
    public function index(Request $request){
      $whereCon = [];
      $catId = '';
      //$whereCon[] = ['user_id','=',Auth::id()];
      if($request->input('title_filter')){
        $whereCon[] = ['title','=',$request->input('title_filter')];
       }

      if($request->input('category')){
         $catId = $request->input('category');
       }

      //DB::enableQueryLog();
      $product = Product::with(['categories'=> function($query) use($catId) {
        if(!empty($catId)){
          $query->where('category_id', '=', $catId);
        }
      }])->where($whereCon)->get();

      //$quries = DB::getQueryLog();
      //dd($quries);
      $categories = Category::all();
      return view('products.product_listing',['products'=>$product, 'categories'=>$categories]);
    }

   //add product function
    public function add_product(){
      $categories = Category::all();
      return view('products.add_product',['categories'=>$categories]);
    }

    //save product function
     public function save_product(Request $request){
       $validatedData = $request->validate([
                'title' => 'required',
                'description' => 'required'
            ],[
                'title.required' => 'Title is required',
                'description.required' => 'Description is required'
            ]);

        $validatedData['user_id'] = Auth::id();
        $product = Product::create($validatedData);
        //dd($product->id);
        $categories = $request->input('category');

        $categoryData =[];
        foreach($categories as $cat){
          $categoryData[]=['product_id'=>$product->id,'category_id'=>$cat];
        }
        Product_category::insert($categoryData);
        return back()->with('success', 'Product created successfully.');

     }

}
