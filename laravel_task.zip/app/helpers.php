<?php
use App\Models\Category;

function get_categoryName($catId){
   $categoryData = Category::find($catId);
   return $categoryData->name;
}

 ?>
