@extends('layouts.app')
@section('title', 'Add Product')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="col-md-6" style="float:left">{{ __('Add Product') }}</div>
                    <div class="col-md-6"style="float:right; text-align:right">
                      <a href="{{ URL::previous() }}" class="btn btn-warning"> <i class="fas fa-arrow-left"></i> Go Back</a>
                    </div>
                </div>
                <div class="card-body">
                  @if(Session::has('success'))
                     <div class="alert alert-success">
                         {{ Session::get('success') }}
                         @php
                             Session::forget('success');
                         @endphp
                     </div>
                 @endif
                  <form action="{{ route('save-product') }}" method="post">
                     {{ csrf_field() }}
                    <div class="form-group">
                      <label for="title">Title:</label>
                      <input type="text" class="form-control" id="title" name="title">
                        @if($errors->has('title'))
                          <span class="text-danger">{{ $errors->first('title') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                      <label for="description">Description:</label>
                      <textarea name="description" class="form-control" id="description"></textarea>
                        @if($errors->has('description'))
                          <span class="text-danger">{{ $errors->first('description') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                      <label for="category">Category:</label>
                        <select name="category[]" class="form-control" id="category" multiple>
                          <option value="">Select Category</option>
                          @foreach($categories as $category)
                          <option value="{{$category->id}}">{{ucfirst($category->name)}}</option>
                          @endforeach
                        </select>
                        @if($errors->has('category'))
                          <span class="text-danger">{{ $errors->first('category') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                  </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection('content')
