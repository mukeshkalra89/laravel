@extends('layouts.app')
@section('title', 'Product List')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="col-md-6" style="float:left">{{ __('Products List') }}</div>
                    <div class="col-md-6"style="float:right; text-align:right">
                      <a class="btn btn-primary" href="{{route('add-product')}}">Add New</a>
                    </div>
                </div>
                <div class="card-header">
                  <form method="post" role="form">
                    {{ csrf_field() }}
                    <input type="text" name="title_filter" placeholder="Title" value="@php if(isset($_POST['title_filter'])){ echo $_POST['title_filter']; } @endphp">
                    <select name="category" class="form-select">
                      <option value="">Select Category</option>
                      @foreach($categories as $category)
                      <option value="{{$category->id}}" @php if(isset($_POST['title_filter']) && $_POST['category'] ==$category->id){ echo 'selected'; } @endphp>{{ucfirst($category->name)}}</option>
                      @endforeach
                    </select>
                    <input type="submit" name="submit" value="Apply Filter" class="btn btn-primary">
                  </form>
                </div>
                <div class="card-body">
                  @if(!empty($products))
                    <table class="table">
                       <thead>
                         <tr>
                           <th>Product Id</th>
                           <th>Product Name</th>
                           <th>Category</th>
                           <th>Created at</th>
                         </tr>
                       </thead>
                       <tbody>
                         @foreach($products as $product)
                          <tr>
                            <td>{{$product->id}}</td>
                            <td>{{$product->title}}</td>
                            <td>
                                @php $categoriesArray = []; @endphp
                                  @foreach($product->categories as $pCat)
                                    @php $categoriesArray[] = get_categoryName("$pCat->category_id")@endphp
                                  @endforeach
                                {{implode(', ',$categoriesArray)}}
                            </td>
                            <td>{{$product->created_at}}</td>
                          </tr>
                         @endforeach
                      </tbody>
                    </table>
                    @else
                     <h2>No Product Found</h2>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
