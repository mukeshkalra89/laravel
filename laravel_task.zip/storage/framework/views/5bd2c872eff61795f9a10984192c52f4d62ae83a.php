<?php $__env->startSection('title', 'Product List'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="col-md-6" style="float:left"><?php echo e(__('Products List')); ?></div>
                    <div class="col-md-6"style="float:right; text-align:right">
                      <a class="btn btn-primary" href="<?php echo e(route('add-product')); ?>">Add New</a>
                    </div>
                </div>
                <div class="card-header">
                  <form method="post" role="form">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" name="title_filter" placeholder="Title" value="<?php if(isset($_POST['title_filter'])){ echo $_POST['title_filter']; } ?>">
                    <select name="category" class="form-select">
                      <option value="">Select Category</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>" <?php if(isset($_POST['title_filter']) && $_POST['category'] ==$category->id){ echo 'selected'; } ?>><?php echo e(ucfirst($category->name)); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="submit" value="Apply Filter" class="btn btn-primary">
                  </form>
                </div>
                <div class="card-body">
                  <?php if(!empty($products)): ?>
                    <table class="table">
                       <thead>
                         <tr>
                           <th>Product Id</th>
                           <th>Product Name</th>
                           <th>Category</th>
                           <th>Created at</th>
                         </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->title); ?></td>
                            <td>
                                <?php $categoriesArray = []; ?>
                                  <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $categoriesArray[] = get_categoryName("$pCat->category_id")?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e(implode(', ',$categoriesArray)); ?>

                            </td>
                            <td><?php echo e($product->created_at); ?></td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <?php else: ?>
                     <h2>No Product Found</h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testjob/resources/views/products/product_listing.blade.php ENDPATH**/ ?>